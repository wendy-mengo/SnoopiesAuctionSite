const mysql = require(`mysql-await`); // npm install mysql-await

var connPool = mysql.createPool({
  connectionLimit: 5,
  host: "127.0.0.1",
  port: 3307,
  user: "C4131F24U84",
  database: "C4131F24U84",
  password: "7106"
});


async function addListing(title, image, description, category, otherCategory, sale_date) {
  if (category == 'Other'){
    const result = await connPool.awaitQuery("insert into listings(title, img, description, category, sale) values (?, ?, ?, ?, ?);", [title, image, description, otherCategory, sale_date])
    return result.insertId

  }
  else{
    const result = await connPool.awaitQuery("insert into listings(title, img, description, category, sale) values (?, ?, ?, ?, ?);", [title, image, description, category, sale_date])
    return result.insertId
  }
}

async function deleteListing(id) {
  const result = await connPool.awaitQuery("delete from listings where id = ?;", [id])
  return result.insertId
}

async function getListing(id) {
  const result = await connPool.awaitQuery("select * from listings where id = ?;", [id])
  console.log(result)
  return result
}

async function getGallery(query) {
  console.log(query.query, query.category)
  const result = await connPool.awaitQuery('select * from listings where title like "%' +query.query+'%" and category like "%' + query.category + '%";')
  return result
}

async function placeBid(listing_id, name, amount, comment) {
  // you CAN change the parameters for this function.
  const result = await connPool.awaitQuery("insert into bids(listingid, name, amount, comment) values (?, ?, ?, ?);", [listing_id, name, amount, comment])
  const listingresult = await connPool.awaitQuery("update listings set topbid= ? where id = ?;", [amount, listing_id])
  return result.insertId
}

async function updateBid(listing_id){
  const addbid = await connPool.awaitQuery("select count(name) as bidcount from bids where listingid = ?;", [listing_id])
  const update = await connPool.awaitQuery("update listings set bidnum = ? where id = ?;", [addbid[0].bidcount, listing_id])
  console.log(addbid)
  return update.insertId
}

async function getBids(listing_id) {
  const result = await connPool.awaitQuery("select * from bids where listingid = ? order by amount desc;", [listing_id])
  return result
}

async function getHighestBid(listing_id) {
  const result = await connPool.awaitQuery("select max(amount) as max from bids where listingid = ?;", [listing_id])
  return result[0].max
}

module.exports = {
    addListing,
    deleteListing,
    getListing,
    getGallery,
    placeBid,
    updateBid,
    getBids,
    getHighestBid
};