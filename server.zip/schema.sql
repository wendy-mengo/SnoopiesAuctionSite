CREATE TABLE listings(
    id int AUTO_INCREMENT,
    title text not null,
    img text not null,
    description text,
    bidnum int default 0,
    category text not null,
    topbid float default 0,
    sale datetime,
    time int,
    primary key (id),
    foreign key bidnum references 
)
INSERT INTO listings (title, img, description, category, bidnum, topbid, sale) values ("Peanuts Christmas", "/images/christmas.png", "It's time to get festive! Put on your ugly sweaters and santa hats, it's Christmas time!! This pie is sure to brighten up any family get-togethers. Something for both adults and children alike!", "Seasonal", 3, 68.99, DATE '2025-09-29');
INSERT INTO listings (title, img, description, category, bidnum, topbid, sale) values ("Pink Birthday", "/images/birthday.jpg", "Whether it's your daughter, wife, or son who really likes pink and snoopy, this cake is perfect for any and everyone! After all, everyone loves snoopy.", "Events", 3, 48.27, DATE '2025-10-4');
INSERT INTO listings (title, img, description, category, bidnum, topbid, sale) values ("Graduation", "/images/graduation.jpg", "What better way to celebrate this milestone than with snoopy??", "Events", 3, 67.98, DATE '2024-9-27');
INSERT INTO listings (title, img, description, category, bidnum, topbid, sale) values ("Music Box Surprise", "/images/Surprise.png", "Surprise! aw snoopy is so cute!", "General", 3, 75.35, DATE '2025-11-23');

CREATE TABLE bids(
    id int AUTO_INCREMENT,
    name text not null,
    amount float not null,
    comment text,
    listingid int not null,
    primary key(id),
    foreign key (listingid) references listings
);

INSERT INTO bids (name, amount, comment, listingid) value("snoopy_luver23", 68.99, "I need to have this.#nojoke #frfr", 1);
INSERT INTO bids (name, amount, comment, listingid) value("peanuts4life", 56.86, "My goal in life is to eat a peanuts cake. #musthave", 1);
INSERT INTO bids (name, amount, comment, listingid) value("gatekeep_snoopy", 54.35, "", 1);

INSERT INTO bids (name, amount, comment, listingid) value("ilovesnoopy", 48.27, "on a scale from one to 10 of how much I love snoopy, I'd say 10000", 2);
INSERT INTO bids (name, amount, comment, listingid) value("myloveforsnoopyknowsnoend", 36.78, "" 2);
INSERT INTO bids (name, amount, comment, listingid) value("brokesnoopyfan", 2.00, "the last $2 I have", 2);

INSERT INTO bids (name, amount, comment, listingid) value("snoopy_234", 67.98, "my parents couldn't make it to my graduation, but maybe snoopy can", 3);
INSERT INTO bids (name, amount, comment, listingid) value("snoopywasmyfirstlove", 46.78, "all I've ever wanted was snoopy" 3);
INSERT INTO bids (name, amount, comment, listingid) value("snoopy", 45.00, "", 3);

INSERT INTO bids (name, amount, comment, listingid) value("snoopynumber1fan", 75.35, "snoopy doesn't know me, but I love him", 4);
INSERT INTO bids (name, amount, comment, listingid) value("snoopyyy", 59.38, "I love snoopy I love snoopy I love snoopy I love snoopy", 4);
INSERT INTO bids (name, amount, comment, listingid) value("<3snoopy<3", 47.59, "I don't know what I'd do without snoopy", 4);