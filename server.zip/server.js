const express = require('express')
const session = require('express-session')
const data = require("./data")
const app = express()
app.use(express.static(__dirname + '/resources'))
app.use(express.urlencoded({extended:true}))
app.use(express.json())
app.set('trust proxy', 1)
app.use(session({
    secret: "mlhgfhjk",
    resave: false,
    saveUninitialized: false,
    cookie:{secure:true, bidder: {}}
}))
app.set("views", "templates");
app.set("view engine", "pug")
const port = 4131


let rateLimitStore = [];
const RATE_LIMIT = 3; // requests per second
const RATE_LIMIT_WINDOW = 10; // seconds

const checkRateLimit = () => {
  const now = new Date();
  rateLimitStore = rateLimitStore.filter(time =>
    (now - time) <= RATE_LIMIT_WINDOW * 1000
  );

  if (rateLimitStore.length >= RATE_LIMIT) {
    const oldestRequest = rateLimitStore[0];
    const retryAfter = RATE_LIMIT_WINDOW - ((now - oldestRequest) / 1000);
    return { passed: false, retryAfter };
  }

  rateLimitStore.push(now);
  return { passed: true };
};

app.get('/', (req , res) => {
  res.render("mainpage.pug")
})

app.get('/main', (req , res) => {
    res.render("mainpage.pug")
})

app.get('/gallery', async(req, res)=>{
    console.log(req.query.query)
    if(JSON.stringify(req.query) === "{}"){
        const galleryid = await data.getGallery({query:"", category: ""})
        console.log(galleryid)
        res.render("gallery.pug", {"listings": galleryid})

    } else{
        const galleryid = await data.getGallery(req.query)
        console.log(galleryid)
        res.render("gallery.pug", {"listings": galleryid})

    }
})

app.get('*listing/:id', async(req, res) => {
    let cleanId = req.params.id
    if (cleanId.includes('listing/')) {
        cleanId = cleanId.split('listing/').pop()
    }
    
    const listingId = parseInt(cleanId)
    const listing = await data.getListing(listingId)
    const bids = await data.getBids(listingId)
    
    if (!listing) {
        return res.status(404).render("404.pug")
    }
    const name = req.session.bidders?.[listingId] || ''

    res.render("listing.pug", {"listing": listing[0], "bids": bids, "name": name})
})


app.get('/create', (req, res)=>{
    res.render("create.pug")
})

app.get('/api/createfail', (req, res)=>{
    res.render("createfail.pug")
})

app.post('/create', async(req, res)=>{
    console.log(req.body)
    const id = await data.addListing(req.body.title, req.body.image, req.body.description, req.body.category, req.body.otherCategory, req.body.date)
    const galleryid = await data.getGallery({query:"", category: ""})
    console.log(id)
    res.render("gallery.pug", {"listings": galleryid})
})

app.post('/api/place_bid', async(req, res) => {
    const result = checkRateLimit()
    
    if (!result.passed) {
        return res.status(429).json({ error: 'Rate limit exceeded' })
    }

    try {
        const listingIndex = parseInt(req.body.listing_id)
        /* if (listingIndex < 0 || listingIndex >= listings.length) {
            return res.status(400).json({ error: 'Invalid listing ID' })
        } */

        const new_bid = {
            listing_id: listingIndex,
            name: req.body.bidder,
            amt: 1.00 * req.body.amount || 0.00,
            comment: req.body.comment || ''
        }
        console.log(new_bid)
        if(new_bid.name === ''){
            return res.status(400).json({ error: 'Invalid bid data' })  // Changed from redirect
        }


        const currentHighestBid = await data.getHighestBid(listingIndex) || 0
        console.log(currentHighestBid)
        if (new_bid.amt <= currentHighestBid) {
            return res.status(409).json({error: 'Invalid amount'})
        }

        if (!req.session.bidders) {
            req.session.bidders = {}
        }
        req.session.bidders[req.body.listing_id] = new_bid.name

        await data.placeBid(new_bid.listing_id, new_bid.name, new_bid.amt, new_bid.comment)
        await data.updateBid(listingIndex)
        const bids = await data.getBids(listingIndex)
        return res.status(201).json({
            bids: bids,
            storedBidder: req.session.bidders[req.body.listing_id]
        })

    } catch (error) {
        console.error('Error placing bid:', error)
        return res.status(500).json({ error: 'Failed to place bid' })
    }
})

app.get('/api/get_bidder/:listing_id', (req, res) => {
    const bidderName = req.session.bidders?.[req.params.listing_id] || '';
    res.json({ bidder: bidderName });
});

app.delete('/api/delete_listing', async(req, res) => {
    const result = checkRateLimit()
    
    if (!result.passed) {
        return res.status(429).json({ error: 'Rate limit exceeded' });
    }

    const listingid = req.body.listing_id;
    
    if (!listingid) {
        return res.status(400).json({ error: 'No listing ID provided' });
    }

    const id = await data.deleteListing(listingid)
    console.log("sdhf")
    const galleryid = await data.getGallery({query:"", category: ""})
    console.log(galleryid)
    res.render("gallery.pug", {"listings": galleryid})
})

app.use((req, res, next)=>{
    res.status(404).render("404.pug")
})

app.get('/css/main.css', (req, res)=>{
    res.render("main.css")
})
app.get('/js/bid.js', (req, res)=>{
    res.render("bid.js")
})
app.get('/js/new_listing.js', (req, res)=>{
    res.render("new_listing.js")
})
app.get('/images/birthday.jpg', (req, res)=>{
    res.render("birthday.jpg")
})
app.get('/images/christmas.jpg', (req, res)=>{
    res.render("christmas.jpg")
})
app.get('/images/graduation.jpg', (req, res)=>{
    res.render("graduation.jpg")
})
app.get('/images/main.jpg', (req, res)=>{
    res.render("main.jpg")
})
app.get('/images/surprise.png', (req, res)=>{
    res.render("Surprise.png")
})

app. listen (port , () => {
  console.log(`Example app listening on port ${port}`)
})