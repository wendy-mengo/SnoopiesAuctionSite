function handleCategoryChange() {
    const category = document.querySelector("#listing_category").value;
    const otherCategoryInput = document.querySelector("#otherCategory");

    if (category == "Other") {
        otherCategoryInput.style.display = 'inline';
    } else {
        otherCategoryInput.style.display = 'none';  
        otherCategoryInput.value = 'inline';  
    }
}

function bannerBlink(){
    const banner = document.querySelector(".banner");
    if (banner.style.display == 'none'){
        banner.style.display = 'inline';
    }else{
        banner.style.display = 'none';
    }
}
setInterval(bannerBlink, 1000);