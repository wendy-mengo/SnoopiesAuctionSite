const table = document.getElementById("gallery_table");

// Store original dates when the page loads
const originalDates = [];
function initializeDates() {
    const rows = table.rows;
    for (let i = 1; i < rows.length; i++) {
        originalDates[i] = new Date(rows[i].cells[4].innerText);
    }
}

function update() {
    const rows = table.rows;
    const now = new Date();
    
    for (let i = 1; i < rows.length; i++) {
        // Use the stored original date instead of reading from the table
        const sale_date = originalDates[i];
        const passed = sale_date.getTime() - now.getTime();
        
        if (passed < 0) {
            rows[i].cells[5].innerHTML = "Auction Ended";
        } else {
            let secs = Math.floor(passed / 1000);
            let mins = Math.floor(secs / 60);
            secs = secs % 60;
            let hours = Math.floor(mins / 60);
            mins = mins % 60;
            let days = Math.floor(hours / 24);
            hours = hours % 24;
            
            rows[i].cells[5].innerHTML = `${days}d ${hours}h ${mins}m ${secs}s`;
        }
    }
}

// Initialize the dates when the page loads
initializeDates();
// Start the update interval
setInterval(update, 1000);

function preview(row) {
    const previewContainer = document.querySelector("#preview");
    const image = row.dataset.image;         // Use dataset instead of innerText
    const desc = row.dataset.description;    // Use dataset instead of innerText
    
    previewContainer.style.display = 'inline';
    previewContainer.innerHTML = `
        <div class="preview-card">
            <img src="${image}" alt="Auction Image" style="width:100%; max-height:300px;">
        </div>
        <div class="preview-card">
            <p>${desc}</p>
        </div>
    `;
}

async function deleteListing(id){
    try {
        const listing = {
            listing_id: id
        }
        const response = await fetch("/api/delete_listing", {
            method: 'DELETE',
            headers: {
                'Content-type': 'application/json'
            },
            body: JSON.stringify(listing)

        });
            if (response.ok) {  
            let rows = document.querySelectorAll("#row");
            rows.forEach((row) => {
                if (row.children['listing_id'].attributes.value.value == id.attributes.value.value) {
                    row.remove();
                }
            });
            window.location.reload();
        } else {
            if (response.status === 404) {
                console.log("Error 404: Resource not found.");
                let rows = document.querySelectorAll("#row");
                rows.forEach((row) => {
                    if (row.children['listing_id'].attributes.value.value == id) {
                        row.remove();
                    }
                });
            } else if (response.status === 400 || response.status === 500) {
                alert("Error " + response.status);
            }
        }
    } catch (error) {
        alert("Error " + response.status);
    }
}

