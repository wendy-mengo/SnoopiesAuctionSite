function bidButton() {
    let button = document.querySelector("#placeBid");
    let form = document.querySelector("#new");

    if (button.innerHTML === "Place Bid") {
        form.style.display = 'inline';  
        button.innerHTML = "Cancel Bid"; 
    } else {
        form.style.display = 'none';  
        button.innerHTML = "Place Bid";  
    }
}
window.addEventListener('load', async () => {
    const listingId = document.getElementById('listing_id').innerText
    const response = await fetch(`/api/get_bidder/${listingId}`)
    const data = await response.json()
    if (data.bidder) {
        document.getElementById('bidder').value = data.bidder
    }
})

async function submitBid(){
    const name = document.getElementById('bidder').value;
    const amt = document.getElementById('amount').value;
    const cmt = document.getElementById('comment').value;
    const id = document.getElementById('listing_id').innerText;


    const bid = {
        bidder: name,
        amount: amt,
        comment: cmt,
        listing_id: id 
    }

    try {
        fetch('/api/place_bid', {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
            },
            body: JSON.stringify(bid),
            credentials: 'include'
        }).then(async (response) => {
            console.log(response.headers);
            if (response.status == 409) {
                document.getElementById("amount").style.borderColor="#FF0000";
            } else if(response.status == 400){
                document.getElementById("bidder").style.borderColor="#FF0000";
            }
            else if(response.status == 201){
                console.log(response.headers);
                const data = await response.json();
                let listBid = document.getElementById('listBid');
                listBid.innerHTML = '';
                data.bids.forEach(bid => {
                    console.log(bid);
                    let item = document.createElement('div');
                    item.innerHTML = `<div class="bid">
                    <h3>
                        <span class="bidder">${bid['name']}</span>
                        <span class="amount">$${bid['amount']}</span>
                    </h3>
                    <span class="comment">${bid['comment']}</span>
                    </div>`;
                    listBid.appendChild(item);
                });
                
                // Pre-fill the bidder name from session for this listing
                document.getElementById('bidder').value = data.storedBidder;
                document.getElementById('amount').value = '';
                document.getElementById('comment').value = '';
                document.getElementById('listing_id').value = ''; 
                document.getElementById("amount").style.borderColor="";

                let button = document.getElementById("placeBid");
                let form = document.querySelector("#new");
                button.innerText = "Place Bid";
                form.style.display = 'none';
            }
        })    
    }catch{
        alert("Error")
    }
} 
